package com.cg.service;

import java.util.List;

import com.cg.dao.EBillDaoImpl;
import com.cg.dao.IEBillDao;
import com.cg.dto.Bill;
import com.cg.exception.BillException;

public class EBillServiceImpl implements IEBillService {

	IEBillDao dao= new EBillDaoImpl();
	
	@Override
	public Bill calBill(Bill bill) {
		
		return dao.calBill(bill);
	}

	@Override
	public int addUsers(Bill bill) {
		
		return dao.addUsers(bill);
	}
	
	public List<Bill> showAll() throws BillException{
		return dao.showAll();
	}

	@Override
	public List<Bill> showBill() throws BillException {
		// TODO Auto-generated method stub
		return dao.showBill();
	}
	
	public List<Bill> search(int con_no) throws BillException{
		return dao.search(con_no);
	}

}
