package com.cg.service;

import com.cg.dto.Bill;

public interface IEBillService {

	public Bill calBill(Bill bill);
	public int addUsers(Bill bill);
}
