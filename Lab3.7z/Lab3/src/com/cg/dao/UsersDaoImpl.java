package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.dto.Users;
import com.cg.exception.UsersException;
import com.cg.util.DbUtil;

public class UsersDaoImpl implements IUsersDao {

	@Override
	public int addUsers(Users users) throws UsersException {
		Connection con = null;
		PreparedStatement ps = null;
		//ResultSet rs = null;
		int status=0;
		try {

			con = DbUtil.obtainConnection();
			String query = "INSERT INTO RegisteredUsers VALUES(?,?,?,?,?,?)";
			ps = con.prepareStatement(query);
			ps.setString(1, users.getFname());
			ps.setString(2, users.getLname());
			ps.setString(3, users.getPassword());
			ps.setString(4, String.valueOf((users.getGender())));
			ps.setString(5, users.getSkill());
			ps.setString(6, users.getCity());

		 status = ps.executeUpdate();
			if(status==1){
				System.out.println("--INSERTED--");
			}

		} catch (UsersException | SQLException e) {
			throw new UsersException("Not Inserted");
		} finally {
			try {
				ps.close();
				con.close();
			} catch (SQLException e) {
				// System.out.println(e.getMessage());
				throw new UsersException("Problem in closing Connection ");
			}

		}

		return status;

	}
	
	
	public List<Users> showAll() throws UsersException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Users>myUsers = new ArrayList<>();
		String query="select firstname,lastname,password,gender,skillset,city from registeredusers";
		try {
			con=DbUtil.obtainConnection();
			ps=con.prepareStatement(query);
			rs= ps.executeQuery();
			while(rs.next()){
				Users users = new Users();
				
				users.setFname(rs.getString("firstname"));
				users.setLname(rs.getString("lastname"));
				users.setPassword(rs.getString("password"));
				//String ch= String.valueOf(users.getGender());
				
				
				String ch= rs.getString("gender");
				users.setGender(ch.charAt(0));
				
				users.setSkill(rs.getString("skillset"));
				users.setCity(rs.getString("city"));
				
				myUsers.add(users);
			}
		} catch (UsersException | SQLException e) {
			throw new UsersException("Problem in show");
		}finally{
			try {
				rs.close();
				ps.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		return myUsers;
	}


}
