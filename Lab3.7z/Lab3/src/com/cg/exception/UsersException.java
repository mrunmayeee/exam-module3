package com.cg.exception;

public class UsersException extends Exception{

	
	public UsersException(){
		
	}
	
	public UsersException(String msg){
		super(msg);
	}
}
