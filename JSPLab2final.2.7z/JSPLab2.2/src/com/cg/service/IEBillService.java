package com.cg.service;

import java.util.List;

import com.cg.dto.Bill;
import com.cg.exception.BillException;

public interface IEBillService {

	public Bill calBill(Bill bill);
	public int addUsers(Bill bill);
	public List<Bill> showAll() throws BillException;
	public List<Bill> showBill() throws BillException;
	public List<Bill> search(int con_no) throws BillException;
}
